from django.apps import AppConfig


class DatahandlerConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "DataHandler"
